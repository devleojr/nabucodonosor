-- phpMyAdmin SQL Dump
-- version 5.1.1deb5ubuntu1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 05, 2023 at 12:54 AM
-- Server version: 8.0.31-0ubuntu0.22.04.1
-- PHP Version: 8.1.2-1ubuntu2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `facilsolucoesdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_banco`
--

CREATE TABLE `tb_banco` (
  `idtb_banco` int NOT NULL,
  `codigo` int DEFAULT NULL,
  `nome` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tb_banco`
--

INSERT INTO `tb_banco` (`idtb_banco`, `codigo`, `nome`) VALUES
(1, 102, 'Caixa Economica Federal');

-- --------------------------------------------------------

--
-- Table structure for table `tb_contrato`
--

CREATE TABLE `tb_contrato` (
  `idtb_contrato` int NOT NULL,
  `codigo` int DEFAULT NULL,
  `prazo` int DEFAULT NULL,
  `valor` float DEFAULT NULL,
  `data_inclusao` datetime DEFAULT NULL,
  `tb_convenio_servico_idtb_convenio_servico` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tb_contrato`
--

INSERT INTO `tb_contrato` (`idtb_contrato`, `codigo`, `prazo`, `valor`, `data_inclusao`, `tb_convenio_servico_idtb_convenio_servico`) VALUES
(1, 4, 12, 52, '2023-01-04 20:29:03', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_convenio`
--

CREATE TABLE `tb_convenio` (
  `tb_convenio` int NOT NULL,
  `codigo` int DEFAULT NULL,
  `convenio` varchar(200) DEFAULT NULL,
  `verba` float DEFAULT NULL,
  `tb_banco_idtb_banco` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tb_convenio`
--

INSERT INTO `tb_convenio` (`tb_convenio`, `codigo`, `convenio`, `verba`, `tb_banco_idtb_banco`) VALUES
(1, 2, 'Prefeitura Municipal de Joao Pessoa', 250, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_convenio_servico`
--

CREATE TABLE `tb_convenio_servico` (
  `idtb_convenio_servico` int NOT NULL,
  `codigo` int DEFAULT NULL,
  `servico` varchar(200) DEFAULT NULL,
  `tb_convenio_tb_convenio` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tb_convenio_servico`
--

INSERT INTO `tb_convenio_servico` (`idtb_convenio_servico`, `codigo`, `servico`, `tb_convenio_tb_convenio`) VALUES
(1, 3, 'Manutencao Sistema de Pagamento', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_banco`
--
ALTER TABLE `tb_banco`
  ADD PRIMARY KEY (`idtb_banco`);

--
-- Indexes for table `tb_contrato`
--
ALTER TABLE `tb_contrato`
  ADD PRIMARY KEY (`idtb_contrato`),
  ADD KEY `fk_tb_contrato_tb_convenio_servico_idx` (`tb_convenio_servico_idtb_convenio_servico`);

--
-- Indexes for table `tb_convenio`
--
ALTER TABLE `tb_convenio`
  ADD PRIMARY KEY (`tb_convenio`),
  ADD KEY `fk_tb_convenio_tb_banco1_idx` (`tb_banco_idtb_banco`);

--
-- Indexes for table `tb_convenio_servico`
--
ALTER TABLE `tb_convenio_servico`
  ADD PRIMARY KEY (`idtb_convenio_servico`),
  ADD KEY `fk_tb_convenio_servico_tb_convenio1_idx` (`tb_convenio_tb_convenio`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_banco`
--
ALTER TABLE `tb_banco`
  MODIFY `idtb_banco` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_contrato`
--
ALTER TABLE `tb_contrato`
  MODIFY `idtb_contrato` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_convenio`
--
ALTER TABLE `tb_convenio`
  MODIFY `tb_convenio` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tb_convenio_servico`
--
ALTER TABLE `tb_convenio_servico`
  MODIFY `idtb_convenio_servico` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_contrato`
--
ALTER TABLE `tb_contrato`
  ADD CONSTRAINT `fk_tb_contrato_tb_convenio_servico` FOREIGN KEY (`tb_convenio_servico_idtb_convenio_servico`) REFERENCES `tb_convenio_servico` (`idtb_convenio_servico`);

--
-- Constraints for table `tb_convenio`
--
ALTER TABLE `tb_convenio`
  ADD CONSTRAINT `fk_tb_convenio_tb_banco1` FOREIGN KEY (`tb_banco_idtb_banco`) REFERENCES `tb_banco` (`idtb_banco`);

--
-- Constraints for table `tb_convenio_servico`
--
ALTER TABLE `tb_convenio_servico`
  ADD CONSTRAINT `fk_tb_convenio_servico_tb_convenio1` FOREIGN KEY (`tb_convenio_tb_convenio`) REFERENCES `tb_convenio` (`tb_convenio`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
