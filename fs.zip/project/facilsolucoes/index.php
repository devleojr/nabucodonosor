<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>FS</title>
    </head>
    <body>
        Hello Word!!!
        <?php
        // put your code here
        ?>
    </body>
</html>