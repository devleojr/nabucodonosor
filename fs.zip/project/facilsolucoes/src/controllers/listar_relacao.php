<?php
ini_set ('display_errors', 1);
ini_set ('display_startup_errors', 1);
error_reporting (E_ALL);
include ('../pdo/pdo.php');
$dados = $pdo->query("SELECT c.verba, ct.codigo, ct.data_inclusao, ct.valor, ct.prazo FROM tb_contrato AS ct "
        . "JOIN tb_convenio_servico AS cs ON ct.tb_convenio_servico_idtb_convenio_servico = cs.idtb_convenio_servico "
        . "JOIN tb_convenio AS c ON c.tb_convenio = cs.idtb_convenio_servico "
        . "JOIN tb_banco AS b ON b.idtb_banco = c.tb_banco_idtb_banco")->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($dados);