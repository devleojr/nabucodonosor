<?php
$db_dsn = 'mysql:host=localhost;port=3306;dbname=facilsolucoesdb';
$db_usuario = 'root';
$db_senha = '';
$db_opcoes = array(
    PDO::ATTR_PERSISTENT => false,
    PDO::ATTR_CASE => PDO::CASE_NATURAL,
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"
);
try {
    $pdo = new PDO($db_dsn, $db_usuario, $db_senha, $db_opcoes);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    trigger_error($e->getMessage());
}
